// $Id$

UC Nelnet Payment Method Module.

This module allows you to configure a NelNet QuikPAY payment method in Drupal's
Ubercart module.

Installation
1. Install the module.
2. Configure the QuikPAY settings at admin/store/settings/payment/edit/methods
   You'll want to be in contact with Financial Services' Nelnet liason in order
   to obtain the proper testing and production servers, as well as 
   authentication keys.

Real Time Payment Notifications (RTPN) will need to hit
http://yourdomain/uc_nelnet/rtpn
in order to notify your Site that a payment has completed.

Note
The "proceed to checkout" link includes a time-sensitive hash. This means
the link will time out. QuikPAY only honors hashes with times within 5 minutes
of the QuikPAY server.  This means
A. You want to make sure your server's time is relatively close to your timezone
   as reported at http://tycho.usno.navy.mil/
B. The "proceed to checkout" link times out for users after 5 minutes, give or
   take. When the user clicks the expired link, QuikPAY will report an error.
   The user can close that window/tab and return to the original page with the
   linke and refresh the page to get a valid link.

Author: 
- Michael Samuelson, mlsamuel@asu.edu, alt^I
Feel free to send questions, bug reports, etc.

Additional contributions in the form of testing and bugfixes:
- Eric Katz
- Jon Sheehan.
