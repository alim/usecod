
DESCRIPTION
--------------------------
Simple module that installs the table {uc_nelnet_log}, implements
hook_log_uc_nelnet_order_save() to save QuikPay RTPNs, and exposes that
data to Views.

INSTALLATION
--------------------------
Install the module as usual, see http://drupal.org/node/70151 for further 
information.
 
PERMISSIONS
--------------------------

MODULES
--------------------------

PAGES
--------------------------

TABLES
--------------------------

BLOCKS
--------------------------

HOOKS
--------------------------

